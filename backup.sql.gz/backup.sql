-- MySQL dump 10.13  Distrib 5.6.24, for Linux (x86_64)
--
-- Host: localhost    Database: webstore_production
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `street` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `tel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_rails_12809c9026` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (1,'平谷区','北京','测试测试',1,'2015-05-28 07:59:41','2015-07-29 23:35:29','13914798831','老侯',0),(2,'昆明','云南','sdfg ',3,'2015-06-05 08:23:34','2015-06-05 08:23:34','13655555555','sad ',0),(3,'昆明','云南','sdfg ',3,'2015-06-05 08:23:36','2015-06-05 08:23:36','13655555555','sad ',0),(4,'昆明','云南','u u 家家户户',2,'2015-06-10 09:42:28','2015-06-10 09:42:28','23444','牛奶',0),(5,'昆明','云南','白云路779号',4,'2015-06-10 15:52:24','2015-06-10 15:52:24','13808792595','谢',0),(6,'昆明','云南','北京路',1,'2015-06-26 02:53:25','2015-06-26 02:53:25','13612345678','new address',0),(7,'曲靖','云南','',5,'2015-07-21 02:31:38','2015-08-11 05:01:31','12345678901','124',1),(8,'昆明','云南','盘龙区锦悦四季7栋1505',6,'2015-07-24 09:50:31','2015-07-24 09:50:31','13911085709','李楠',0),(9,'怀柔区','北京','jeff',5,'2015-08-11 09:25:05','2015-08-11 09:25:05','13759581670','jeff',0),(10,'西城区','北京','冠英园西区23#6-604',6,'2015-08-22 07:03:19','2015-08-22 07:03:19','13911085709','李楠',0),(11,'东城区','北京','dajkljalsdjklkdsjl',7,'2015-08-25 04:57:55','2015-08-25 04:57:55','dfafads','dfafa',0),(12,'海淀区','北京','大西洋新城210楼2门18A',9,'2015-08-25 12:40:00','2015-08-25 12:43:33','13811393962','唐小燕',1),(13,'朝阳区','北京','大西洋新城210楼2门18A',9,'2015-08-25 12:42:00','2015-08-25 12:43:47','13811393962','唐小燕',1),(14,'朝阳区','北京','北三环东路六号国展服务楼一层',10,'2015-08-25 13:55:09','2015-08-25 13:55:09','13911667229','刘宏坤',0);
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (1,'北京拾惠社_2015七夕节食材做法','<h3>拾惠社七夕送友人\"有机盒子\"食材介绍</h3><p><img src=\"http://uploads.tenhs.com/images/20150820/7634e6b0-4c95-4b32-ab0c-90cf21a01b04.png\"><img src=\"http://uploads.tenhs.com/images/20150820/b096bb12-4162-4380-96ab-6e224a5e244e.png\"></p><p><img src=\"http://uploads.tenhs.com/images/20150820/c6df092f-d8b5-48b1-a0f6-8a8d60aed8e1.png\"></p><img src=\"http://uploads.tenhs.com/images/20150820/7df970a9-ddf5-453d-9f8a-223228513caa.png\"><br>','2015-08-20 01:51:25','2015-08-20 01:51:25');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `captchas`
--

DROP TABLE IF EXISTS `captchas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `captchas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tel` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `register_token` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `register_sent_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_captchas_on_tel` (`tel`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `captchas`
--

LOCK TABLES `captchas` WRITE;
/*!40000 ALTER TABLE `captchas` DISABLE KEYS */;
INSERT INTO `captchas` VALUES (1,'13914798831','537176','2015-07-21 01:14:26','2015-07-08 00:54:48','2015-07-21 01:04:38'),(2,'13911085709','819427','2015-08-05 05:50:43','2015-07-09 02:43:14','2015-08-05 05:40:44'),(3,'13759581670','666518','2015-07-24 08:09:33','2015-07-21 02:29:32','2015-07-24 07:59:39'),(4,'13808792595','290234','2015-08-10 08:49:54','2015-08-10 08:39:57','2015-08-10 08:39:57'),(5,'13700666697','083925','2015-08-11 09:34:08','2015-08-11 09:22:33','2015-08-11 09:24:14'),(6,'13910106520','595515','2015-08-21 03:35:44','2015-08-21 03:25:46','2015-08-21 03:25:46'),(7,'13811393962','727525','2015-08-25 12:47:23','2015-08-25 12:36:32','2015-08-25 12:37:30'),(8,'13911667229','875233','2015-08-25 14:00:25','2015-08-25 13:50:32','2015-08-25 13:50:32');
/*!40000 ALTER TABLE `captchas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'拾惠社','2015-05-28 05:42:46','2015-05-28 05:42:46',0);
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `seller_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `order_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  `payment_type` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `fk_rails_a6ba8c8794` (`address_id`) USING BTREE,
  KEY `fk_rails_c2426400ce` (`customer_id`) USING BTREE,
  KEY `fk_rails_4498acc18a` (`seller_id`) USING BTREE,
  CONSTRAINT `fk_rails_28d01400ec` FOREIGN KEY (`seller_id`) REFERENCES `groups` (`id`),
  CONSTRAINT `fk_rails_3007af5a30` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`),
  CONSTRAINT `fk_rails_895d744bdb` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,4,0.10,1,1,'2015-05-28 08:02:46','2015-06-02 03:54:40','3324234-123123',1,0,'拾惠社',NULL),(2,2,0.10,1,1,'2015-06-02 03:55:00','2015-08-13 04:35:22','6317710-8857766',1,0,'咖啡树',NULL),(3,0,0.10,1,1,'2015-06-02 05:05:48','2015-06-02 05:05:48','724164-5037258',1,0,'咖啡树',NULL),(4,0,1080.00,1,3,'2015-06-05 08:23:52','2015-06-05 08:23:52','4575908-7714273',3,0,'蔬菜 每周1箱',NULL),(5,0,298.00,1,1,'2015-06-07 01:11:35','2015-06-07 01:11:35','5164709-7998521',1,0,'西双版纳小耳猪',NULL),(6,4,597.00,1,1,'2015-06-07 14:15:17','2015-06-08 11:24:23','4259826-8395106',1,0,'云南小粒咖啡树认养等',NULL),(7,4,298.00,1,1,'2015-06-07 14:39:36','2015-06-10 00:31:42','6704142-7871887',1,0,'西双版纳小耳猪',NULL),(8,0,238.00,1,1,'2015-06-10 00:30:41','2015-06-10 00:30:41','8175845-8900121',1,0,'“有机盒子”果蔬健康搭配5.5公斤／盒',NULL),(9,4,298.00,1,1,'2015-06-10 04:38:03','2015-07-27 03:01:55','561122-9153556',1,0,'西双版纳小耳猪',NULL),(10,0,298.00,1,2,'2015-06-10 09:42:35','2015-06-10 09:42:35','9416939-9966661',4,0,'西双版纳小耳猪',NULL),(11,0,238.00,1,4,'2015-06-10 15:52:38','2015-06-10 15:52:38','1722063-210003',5,0,'“有机盒子”果蔬健康搭配5.5公斤／盒',NULL),(12,0,476.00,1,4,'2015-06-19 06:22:40','2015-06-19 06:22:40','1487625-9241568',5,0,'“有机盒子”果蔬健康搭配5.5公斤／盒',NULL),(13,0,238.00,1,4,'2015-06-30 12:48:50','2015-06-30 12:48:50','8299716-9327178',5,0,'“有机盒子”果蔬健康搭配5.5公斤／盒',NULL),(14,0,238.00,1,4,'2015-07-02 06:18:10','2015-07-02 06:18:10','700159-1710663',5,0,'“有机盒子”果蔬健康搭配5.5公斤／盒',NULL),(15,0,238.00,1,4,'2015-07-02 06:20:14','2015-07-02 06:20:14','4024762-4009804',5,0,'“有机盒子”果蔬健康搭配5.5公斤／盒',NULL),(16,4,1.00,1,1,'2015-07-02 07:07:13','2015-07-08 02:03:49','795794-4967194',1,0,'补差价',NULL),(17,1,1.00,1,4,'2015-07-02 07:14:59','2015-07-02 07:19:21','7101217-6028498',5,0,'补差价',NULL),(18,4,1.00,1,1,'2015-07-02 07:25:03','2015-07-02 07:27:19','7842284-5957658',1,0,'补差价',NULL),(19,0,2.00,1,5,'2015-07-21 02:31:54','2015-07-21 02:31:54','6865418-6219959',7,0,'补差价',NULL),(20,1,1.00,1,6,'2015-07-24 09:50:43','2015-08-22 07:08:51','2178481-2715730',8,0,'补差价','{\"appid\":\"wx869f67bde2dbdbdb\",\"bank_type\":\"HXB_DEBIT\",\"cash_fee\":\"100\",\"fee_type\":\"CNY\",\"is_subscribe\":\"Y\",\"mch_id\":\"1251582801\",\"nonce_str\":\"8308480669668152\",\"openid\":\"o4_vLvrgI_TDU0x0G0ZoL-Gp1LQg\",\"out_trade_no\":\"2178481-2715730\",\"result_code\":\"SUCCESS\",\"return_code\":\"SUCCESS\",\"sign\":\"5A0E1F0CA28F8D6A144AFA4405C42BF1\",\"time_end\":\"20150822150850\",\"total_fee\":\"100\",\"trade_type\":\"JSAPI\",\"transaction_id\":\"1007860394201508220681758215\"}'),(21,0,1.00,1,2,'2015-07-27 02:56:25','2015-07-27 02:56:25','4748483-3565375',4,0,'补差价',NULL),(22,1,1.00,1,1,'2015-07-27 03:00:24','2015-07-29 06:22:29','9252817-6370323',1,0,'补差价',NULL),(23,0,1.00,1,5,'2015-07-28 02:44:57','2015-07-28 02:44:57','7966602-7423395',7,0,'补差价',NULL),(24,0,1.00,1,5,'2015-07-28 03:07:50','2015-07-28 03:07:50','2220090-3602817',7,0,'补差价',NULL),(25,0,1.00,1,5,'2015-07-28 07:13:36','2015-07-28 07:13:36','5620706-1558249',7,0,'补差价',NULL),(26,0,1.00,1,5,'2015-07-28 12:33:09','2015-07-28 12:33:09','4148353-4179375',7,0,'补差价',NULL),(27,4,0.10,1,1,'2015-07-29 06:15:23','2015-07-30 03:18:37','9792550-966866',1,0,'补差价',NULL),(28,1,0.10,1,1,'2015-07-29 06:29:41','2015-07-29 06:29:57','5309521-748277',1,0,'补差价',NULL),(29,1,0.10,1,1,'2015-07-29 06:36:40','2015-07-29 06:36:56','869258-8655409',6,0,'补差价',NULL),(30,0,0.20,1,5,'2015-07-29 10:51:02','2015-07-29 10:51:02','3474252-4678346',7,0,'补差价',NULL),(31,0,0.10,1,5,'2015-07-29 10:53:57','2015-07-29 10:53:57','7590107-4261221',7,1,'补差价',NULL),(32,0,0.10,1,5,'2015-07-29 11:01:01','2015-07-29 11:01:01','4509620-761508',7,0,'补差价',NULL),(33,0,0.10,1,5,'2015-07-29 12:11:25','2015-07-29 12:11:25','581468-8753258',7,1,'补差价',NULL),(34,1,0.10,1,5,'2015-07-29 12:12:44','2015-07-29 12:13:14','7276090-117958',7,0,'补差价',NULL),(35,1,0.10,1,1,'2015-07-30 01:55:16','2015-07-30 02:39:03','8976209-7760251',1,1,'补差价',NULL),(36,1,0.10,1,1,'2015-07-30 03:01:49','2015-07-30 03:08:36','6153176-7729209',1,0,'补差价','{\"xml\":{\"appid\":\"wx869f67bde2dbdbdb\",\"bank_type\":\"CMB_DEBIT\",\"cash_fee\":\"10\",\"fee_type\":\"CNY\",\"is_subscribe\":\"Y\",\"mch_id\":\"1251582801\",\"nonce_str\":\"9455677640837753\",\"openid\":\"o4_vLvmWp1S7wydtQGfhcPjJtbWU\",\"out_trade_no\":\"6153176-7729209\",\"result_code\":\"SUCCESS\",\"return_code\":\"SUCCESS\",\"sign\":\"D18D14151D069AECB0725B404080DF07\",\"time_end\":\"20150730110826\",\"total_fee\":\"10\",\"trade_type\":\"JSAPI\",\"transaction_id\":\"1004650394201507300506392661\"}}'),(37,1,0.10,1,1,'2015-07-30 03:12:24','2015-07-30 03:13:09','4824625-7916787',1,1,'补差价','{\"payment_type\":\"1\",\"subject\":\"补差价\",\"trade_no\":\"2015073000001000270078657172\",\"buyer_email\":\"rex.houy@gmail.com\",\"gmt_create\":\"2015-07-30 11:13:07\",\"notify_type\":\"trade_status_sync\",\"quantity\":\"1\",\"out_trade_no\":\"4824625-7916787\",\"seller_id\":\"2088911911006532\",\"notify_time\":\"2015-07-30 11:13:09\",\"body\":\"补差价,1件;\",\"trade_status\":\"TRADE_SUCCESS\",\"is_total_fee_adjust\":\"N\",\"total_fee\":\"0.10\",\"gmt_payment\":\"2015-07-30 11:13:08\",\"seller_email\":\"86199273@qq.com\",\"price\":\"0.10\",\"buyer_id\":\"2088502880353275\",\"notify_id\":\"abfc0bf4f655096e17fb526470d7c7f33i\",\"use_coupon\":\"N\",\"sign_type\":\"MD5\",\"sign\":\"4bbd26fe0f8fd0106ae6c03e40a21c5e\",\"controller\":\"api/payments\",\"action\":\"alipay_notify\"}'),(38,1,0.10,1,1,'2015-07-30 03:27:25','2015-07-30 03:27:44','8319821-1191317',1,0,'补差价','{\"appid\":\"wx869f67bde2dbdbdb\",\"bank_type\":\"CMB_DEBIT\",\"cash_fee\":\"10\",\"fee_type\":\"CNY\",\"is_subscribe\":\"Y\",\"mch_id\":\"1251582801\",\"nonce_str\":\"7491342541740332\",\"openid\":\"o4_vLvmWp1S7wydtQGfhcPjJtbWU\",\"out_trade_no\":\"8319821-1191317\",\"result_code\":\"SUCCESS\",\"return_code\":\"SUCCESS\",\"sign\":\"3D9A4048793C002C8FDEF10C83AEA7A7\",\"time_end\":\"20150730112741\",\"total_fee\":\"10\",\"trade_type\":\"JSAPI\",\"transaction_id\":\"1004650394201507300506495440\"}'),(39,0,0.20,1,5,'2015-07-30 09:18:52','2015-07-30 09:18:52','3430574-5363215',7,1,'补差价',NULL),(40,0,0.10,1,5,'2015-07-30 09:24:28','2015-07-30 09:24:28','5474364-2830134',7,1,'补差价',NULL),(41,0,0.10,1,5,'2015-07-30 09:25:43','2015-07-30 09:25:43','1223418-6070845',7,0,'补差价',NULL),(42,0,0.10,1,5,'2015-07-30 09:36:02','2015-07-30 09:36:02','455522-1255626',7,0,'补差价',NULL),(43,0,0.10,1,5,'2015-07-31 12:55:14','2015-07-31 12:55:14','5899287-3214901',7,1,'补差价',NULL),(44,4,0.10,1,5,'2015-07-31 16:06:21','2015-07-31 16:06:41','359528-6725419',7,1,'补差价',NULL),(45,1,0.10,1,1,'2015-08-02 05:12:23','2015-08-02 05:12:47','7222328-5325121',1,1,'补差价','{\"payment_type\":\"1\",\"subject\":\"补差价\",\"trade_no\":\"2015080200001000270078993757\",\"buyer_email\":\"rex.houy@gmail.com\",\"gmt_create\":\"2015-08-02 13:12:45\",\"notify_type\":\"trade_status_sync\",\"quantity\":\"1\",\"out_trade_no\":\"7222328-5325121\",\"seller_id\":\"2088911911006532\",\"notify_time\":\"2015-08-02 13:12:46\",\"body\":\"补差价,1件;\",\"trade_status\":\"TRADE_SUCCESS\",\"is_total_fee_adjust\":\"N\",\"total_fee\":\"0.10\",\"gmt_payment\":\"2015-08-02 13:12:46\",\"seller_email\":\"86199273@qq.com\",\"price\":\"0.10\",\"buyer_id\":\"2088502880353275\",\"notify_id\":\"221879662ac3e55ba963a45c674908853i\",\"use_coupon\":\"N\",\"sign_type\":\"MD5\",\"sign\":\"3698a382a0855aa4ce5c4dc3142fda81\",\"controller\":\"api/payments\",\"action\":\"alipay_notify\"}'),(46,0,0.10,1,5,'2015-08-02 05:23:36','2015-08-02 05:23:36','6789621-9758385',7,1,'补差价',NULL),(47,0,0.10,1,1,'2015-08-03 14:43:46','2015-08-03 14:43:46','611183-837763',1,1,'补差价',NULL),(48,1,0.10,1,1,'2015-08-04 07:22:11','2015-08-04 07:22:30','1851799-766558',1,0,'补差价','{\"appid\":\"wx869f67bde2dbdbdb\",\"bank_type\":\"CMB_DEBIT\",\"cash_fee\":\"10\",\"fee_type\":\"CNY\",\"is_subscribe\":\"Y\",\"mch_id\":\"1251582801\",\"nonce_str\":\"2492014366880715\",\"openid\":\"o4_vLvmWp1S7wydtQGfhcPjJtbWU\",\"out_trade_no\":\"1851799-766558\",\"result_code\":\"SUCCESS\",\"return_code\":\"SUCCESS\",\"sign\":\"8EA3713D4AFFACA53B3FD4F51D2E2C3A\",\"time_end\":\"20150804152225\",\"total_fee\":\"10\",\"trade_type\":\"JSAPI\",\"transaction_id\":\"1004650394201508040546784980\"}'),(49,1,0.10,1,1,'2015-08-04 07:23:52','2015-08-04 07:24:10','3517368-605575',1,1,'补差价','{\"payment_type\":\"1\",\"subject\":\"补差价\",\"trade_no\":\"2015080400001000270079198974\",\"buyer_email\":\"rex.houy@gmail.com\",\"gmt_create\":\"2015-08-04 15:24:08\",\"notify_type\":\"trade_status_sync\",\"quantity\":\"1\",\"out_trade_no\":\"3517368-605575\",\"seller_id\":\"2088911911006532\",\"notify_time\":\"2015-08-04 15:24:09\",\"body\":\"补差价,1件;\",\"trade_status\":\"TRADE_SUCCESS\",\"is_total_fee_adjust\":\"N\",\"total_fee\":\"0.10\",\"gmt_payment\":\"2015-08-04 15:24:09\",\"seller_email\":\"86199273@qq.com\",\"price\":\"0.10\",\"buyer_id\":\"2088502880353275\",\"notify_id\":\"1360a90e22b858e6daa81b5f4ccf5a753i\",\"use_coupon\":\"N\",\"sign_type\":\"MD5\",\"sign\":\"e51a443486799e3cc312c52292de1e5d\",\"controller\":\"api/payments\",\"action\":\"alipay_notify\"}'),(50,1,0.10,1,1,'2015-08-04 07:26:02','2015-08-04 07:27:50','3590937-999187',1,0,'补差价','{\"appid\":\"wx869f67bde2dbdbdb\",\"bank_type\":\"CMB_DEBIT\",\"cash_fee\":\"10\",\"fee_type\":\"CNY\",\"is_subscribe\":\"Y\",\"mch_id\":\"1251582801\",\"nonce_str\":\"2155351300594465\",\"openid\":\"o4_vLvmWp1S7wydtQGfhcPjJtbWU\",\"out_trade_no\":\"3590937-999187\",\"result_code\":\"SUCCESS\",\"return_code\":\"SUCCESS\",\"sign\":\"33565676123BF2F96E74D7C7794DB84A\",\"time_end\":\"20150804152737\",\"total_fee\":\"10\",\"trade_type\":\"JSAPI\",\"transaction_id\":\"1004650394201508040546851471\"}'),(51,1,0.10,1,1,'2015-08-04 10:54:06','2015-08-04 10:54:18','4106835-8029977',1,1,'补差价','{\"payment_type\":\"1\",\"subject\":\"补差价\",\"trade_no\":\"2015080400001000270079219919\",\"buyer_email\":\"rex.houy@gmail.com\",\"gmt_create\":\"2015-08-04 18:54:16\",\"notify_type\":\"trade_status_sync\",\"quantity\":\"1\",\"out_trade_no\":\"4106835-8029977\",\"seller_id\":\"2088911911006532\",\"notify_time\":\"2015-08-04 18:54:18\",\"body\":\"补差价,1件;\",\"trade_status\":\"TRADE_SUCCESS\",\"is_total_fee_adjust\":\"N\",\"total_fee\":\"0.10\",\"gmt_payment\":\"2015-08-04 18:54:18\",\"seller_email\":\"86199273@qq.com\",\"price\":\"0.10\",\"buyer_id\":\"2088502880353275\",\"notify_id\":\"e73d9deb0ebbd660c1d539479868429a3i\",\"use_coupon\":\"N\",\"sign_type\":\"MD5\",\"sign\":\"cf43b96b2b6a2282e880c24e8ace1f24\",\"controller\":\"api/payments\",\"action\":\"alipay_notify\"}'),(52,1,0.10,1,1,'2015-08-04 11:04:27','2015-08-04 11:04:49','9000964-799250',1,1,'补差价','{\"payment_type\":\"1\",\"subject\":\"补差价\",\"trade_no\":\"2015080400001000270079220892\",\"buyer_email\":\"rex.houy@gmail.com\",\"gmt_create\":\"2015-08-04 19:04:47\",\"notify_type\":\"trade_status_sync\",\"quantity\":\"1\",\"out_trade_no\":\"9000964-799250\",\"seller_id\":\"2088911911006532\",\"notify_time\":\"2015-08-04 19:04:49\",\"body\":\"补差价,1件;\",\"trade_status\":\"TRADE_SUCCESS\",\"is_total_fee_adjust\":\"N\",\"total_fee\":\"0.10\",\"gmt_payment\":\"2015-08-04 19:04:48\",\"seller_email\":\"86199273@qq.com\",\"price\":\"0.10\",\"buyer_id\":\"2088502880353275\",\"notify_id\":\"387e35736c76f37bd4c27dbcdbe2bcec3i\",\"use_coupon\":\"N\",\"sign_type\":\"MD5\",\"sign\":\"35dbb8a12352ef82550efb70416a9d13\",\"controller\":\"api/payments\",\"action\":\"alipay_notify\"}'),(53,1,0.10,1,1,'2015-08-04 11:06:48','2015-08-04 11:06:57','3065737-3695461',1,1,'补差价','{\"payment_type\":\"1\",\"subject\":\"补差价\",\"trade_no\":\"2015080400001000270079221051\",\"buyer_email\":\"rex.houy@gmail.com\",\"gmt_create\":\"2015-08-04 19:06:55\",\"notify_type\":\"trade_status_sync\",\"quantity\":\"1\",\"out_trade_no\":\"3065737-3695461\",\"seller_id\":\"2088911911006532\",\"notify_time\":\"2015-08-04 19:06:57\",\"body\":\"补差价,1件;\",\"trade_status\":\"TRADE_SUCCESS\",\"is_total_fee_adjust\":\"N\",\"total_fee\":\"0.10\",\"gmt_payment\":\"2015-08-04 19:06:57\",\"seller_email\":\"86199273@qq.com\",\"price\":\"0.10\",\"buyer_id\":\"2088502880353275\",\"notify_id\":\"b9640600b2d73f12582f6f201d88198b3i\",\"use_coupon\":\"N\",\"sign_type\":\"MD5\",\"sign\":\"16142b8a2d03aa29b41bc8958551a75c\",\"controller\":\"api/payments\",\"action\":\"alipay_notify\"}'),(54,1,0.10,1,1,'2015-08-04 11:09:53','2015-08-04 11:10:04','8937437-7008936',1,1,'补差价','{\"payment_type\":\"1\",\"subject\":\"补差价\",\"trade_no\":\"2015080400001000270079221363\",\"buyer_email\":\"rex.houy@gmail.com\",\"gmt_create\":\"2015-08-04 19:10:02\",\"notify_type\":\"trade_status_sync\",\"quantity\":\"1\",\"out_trade_no\":\"8937437-7008936\",\"seller_id\":\"2088911911006532\",\"notify_time\":\"2015-08-04 19:10:03\",\"body\":\"补差价,1件;\",\"trade_status\":\"TRADE_SUCCESS\",\"is_total_fee_adjust\":\"N\",\"total_fee\":\"0.10\",\"gmt_payment\":\"2015-08-04 19:10:03\",\"seller_email\":\"86199273@qq.com\",\"price\":\"0.10\",\"buyer_id\":\"2088502880353275\",\"notify_id\":\"583bdd849b77b92d43ccd7692aec9e333i\",\"use_coupon\":\"N\",\"sign_type\":\"MD5\",\"sign\":\"979f1c56f875a7bf0333cf3b971c953a\",\"controller\":\"api/payments\",\"action\":\"alipay_notify\"}'),(55,0,0.10,1,5,'2015-08-04 15:38:13','2015-08-04 15:38:13','4842992-8578884',7,0,'补差价',NULL),(56,1,0.10,1,1,'2015-08-05 03:23:58','2015-08-05 03:24:12','4578261-8241429',1,0,'补差价','{\"appid\":\"wx869f67bde2dbdbdb\",\"bank_type\":\"CMB_DEBIT\",\"cash_fee\":\"10\",\"fee_type\":\"CNY\",\"is_subscribe\":\"Y\",\"mch_id\":\"1251582801\",\"nonce_str\":\"4293594983662254\",\"openid\":\"o4_vLvmWp1S7wydtQGfhcPjJtbWU\",\"out_trade_no\":\"4578261-8241429\",\"result_code\":\"SUCCESS\",\"return_code\":\"SUCCESS\",\"sign\":\"7D5A5E673C92DB7D9BE7C8528C6C1235\",\"time_end\":\"20150805112411\",\"total_fee\":\"10\",\"trade_type\":\"JSAPI\",\"transaction_id\":\"1004650394201508050553163607\"}'),(57,1,0.10,1,1,'2015-08-05 03:53:24','2015-08-05 03:53:36','8229002-1601401',1,1,'补差价','{\"payment_type\":\"1\",\"subject\":\"补差价\",\"trade_no\":\"2015080500001000270079277630\",\"buyer_email\":\"rex.houy@gmail.com\",\"gmt_create\":\"2015-08-05 11:53:34\",\"notify_type\":\"trade_status_sync\",\"quantity\":\"1\",\"out_trade_no\":\"8229002-1601401\",\"seller_id\":\"2088911911006532\",\"notify_time\":\"2015-08-05 11:53:35\",\"body\":\"补差价,1件;\",\"trade_status\":\"TRADE_SUCCESS\",\"is_total_fee_adjust\":\"N\",\"total_fee\":\"0.10\",\"gmt_payment\":\"2015-08-05 11:53:35\",\"seller_email\":\"86199273@qq.com\",\"price\":\"0.10\",\"buyer_id\":\"2088502880353275\",\"notify_id\":\"fe4a8bae3b04202317248182b7b0387e3i\",\"use_coupon\":\"N\",\"sign_type\":\"MD5\",\"sign\":\"3eed3828b862d40cf8f4cb5404fe2126\",\"controller\":\"api/payments\",\"action\":\"alipay_notify\"}'),(58,0,238.00,1,5,'2015-08-06 04:01:30','2015-08-06 04:01:30','3554433-9316036',7,1,'“有机盒子”果蔬健康搭配5.5公斤／盒',NULL),(59,0,1.00,1,5,'2015-08-11 09:25:13','2015-08-11 09:25:13','5486641-578794',9,0,'补差价',NULL),(60,0,1.00,1,5,'2015-08-11 09:26:25','2015-08-11 09:26:25','9436053-643674',9,1,'补差价',NULL),(61,0,1.00,1,5,'2015-08-13 04:56:21','2015-08-13 04:56:21','7870674-6286610',9,1,'补差价',NULL),(62,4,1.00,1,6,'2015-08-22 07:07:23','2015-08-22 07:08:20','1780603-2607766',10,1,'补差价',NULL),(63,0,1.00,1,5,'2015-08-22 07:15:31','2015-08-22 07:15:31','2789031-5580955',9,1,'补差价',NULL),(64,4,960.00,1,7,'2015-08-25 04:58:51','2015-08-25 12:52:58','2712191-487467',11,0,'澳大利亚布姆兰干红',NULL),(65,1,238.00,1,9,'2015-08-25 12:42:19','2015-08-25 12:42:31','2036383-1270765',12,0,'“有机盒子”果蔬健康搭配5.5公斤／盒','{\"appid\":\"wx869f67bde2dbdbdb\",\"bank_type\":\"CMBC_DEBIT\",\"cash_fee\":\"23800\",\"fee_type\":\"CNY\",\"is_subscribe\":\"N\",\"mch_id\":\"1251582801\",\"nonce_str\":\"9117046384145352\",\"openid\":\"o4_vLvqnczS6WzA1OGlPP3WpH9jU\",\"out_trade_no\":\"2036383-1270765\",\"result_code\":\"SUCCESS\",\"return_code\":\"SUCCESS\",\"sign\":\"8C981FDAA930E946C26C1AFA66F36E1D\",\"time_end\":\"20150825204229\",\"total_fee\":\"23800\",\"trade_type\":\"JSAPI\",\"transaction_id\":\"1001400394201508250708181204\"}'),(66,1,102.00,1,10,'2015-08-25 13:58:18','2015-08-25 13:58:35','9287082-9544142',14,0,'生态越南野鸡','{\"appid\":\"wx869f67bde2dbdbdb\",\"bank_type\":\"CFT\",\"cash_fee\":\"10200\",\"fee_type\":\"CNY\",\"is_subscribe\":\"Y\",\"mch_id\":\"1251582801\",\"nonce_str\":\"7888392034348604\",\"openid\":\"o4_vLvoSv-eez0ullOJDOIILRa2w\",\"out_trade_no\":\"9287082-9544142\",\"result_code\":\"SUCCESS\",\"return_code\":\"SUCCESS\",\"sign\":\"6DEBAD09B1AC0A4202DF9DCA8D517119\",\"time_end\":\"20150825215833\",\"total_fee\":\"10200\",\"trade_type\":\"JSAPI\",\"transaction_id\":\"1001310394201508250708705129\"}');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_products`
--

DROP TABLE IF EXISTS `orders_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `count` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `specification_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_rails_889bfce267` (`order_id`) USING BTREE,
  KEY `fk_rails_331586c13a` (`product_id`) USING BTREE,
  KEY `index_orders_products_on_specification_id` (`specification_id`) USING BTREE,
  CONSTRAINT `fk_rails_2006f0f039` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `fk_rails_52378f5db5` FOREIGN KEY (`specification_id`) REFERENCES `specifications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rails_641f4bb155` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_products`
--

LOCK TABLES `orders_products` WRITE;
/*!40000 ALTER TABLE `orders_products` DISABLE KEYS */;
INSERT INTO `orders_products` VALUES (1,1,0.10,1,3,'2015-05-28 08:02:46','2015-05-28 08:02:46',NULL),(2,1,0.10,2,3,'2015-06-02 03:55:00','2015-06-02 03:55:00',NULL),(3,1,0.10,3,3,'2015-06-02 05:05:48','2015-06-02 05:05:48',NULL),(4,1,1080.00,4,2,'2015-06-05 08:23:52','2015-06-05 08:23:52',1),(5,1,298.00,5,1,'2015-06-07 01:11:35','2015-06-07 01:11:35',3),(6,1,299.00,6,3,'2015-06-07 14:15:17','2015-06-07 14:15:17',NULL),(7,1,298.00,6,1,'2015-06-07 14:15:17','2015-06-07 14:15:17',3),(8,1,298.00,7,1,'2015-06-07 14:39:36','2015-06-07 14:39:36',3),(9,1,238.00,8,2,'2015-06-10 00:30:41','2015-06-10 00:30:41',1),(10,1,298.00,9,1,'2015-06-10 04:38:03','2015-06-10 04:38:03',3),(11,1,298.00,10,1,'2015-06-10 09:42:35','2015-06-10 09:42:35',3),(12,1,238.00,11,2,'2015-06-10 15:52:38','2015-06-10 15:52:38',1),(13,2,238.00,12,2,'2015-06-19 06:22:40','2015-06-19 06:22:40',1),(14,1,238.00,13,2,'2015-06-30 12:48:50','2015-06-30 12:48:50',1),(15,1,238.00,14,2,'2015-07-02 06:18:10','2015-07-02 06:18:10',1),(16,1,238.00,15,2,'2015-07-02 06:20:14','2015-07-02 06:20:14',1),(17,1,1.00,16,4,'2015-07-02 07:07:13','2015-07-02 07:07:13',NULL),(18,1,1.00,17,4,'2015-07-02 07:14:59','2015-07-02 07:14:59',NULL),(19,1,1.00,18,4,'2015-07-02 07:25:03','2015-07-02 07:25:03',NULL),(20,2,1.00,19,4,'2015-07-21 02:31:54','2015-07-21 02:31:54',NULL),(21,1,1.00,20,4,'2015-07-24 09:50:43','2015-07-24 09:50:43',NULL),(22,1,1.00,21,4,'2015-07-27 02:56:25','2015-07-27 02:56:25',NULL),(23,1,1.00,22,4,'2015-07-27 03:00:24','2015-07-27 03:00:24',NULL),(24,1,1.00,23,4,'2015-07-28 02:44:57','2015-07-28 02:44:57',NULL),(25,1,1.00,24,4,'2015-07-28 03:07:50','2015-07-28 03:07:50',NULL),(26,1,1.00,25,4,'2015-07-28 07:13:36','2015-07-28 07:13:36',NULL),(27,1,1.00,26,4,'2015-07-28 12:33:09','2015-07-28 12:33:09',NULL),(28,1,0.10,27,4,'2015-07-29 06:15:23','2015-07-29 06:15:23',NULL),(29,1,0.10,28,4,'2015-07-29 06:29:41','2015-07-29 06:29:41',NULL),(30,1,0.10,29,4,'2015-07-29 06:36:40','2015-07-29 06:36:40',NULL),(31,2,0.10,30,4,'2015-07-29 10:51:02','2015-07-29 10:51:02',NULL),(32,1,0.10,31,4,'2015-07-29 10:53:57','2015-07-29 10:53:57',NULL),(33,1,0.10,32,4,'2015-07-29 11:01:01','2015-07-29 11:01:01',NULL),(34,1,0.10,33,4,'2015-07-29 12:11:25','2015-07-29 12:11:25',NULL),(35,1,0.10,34,4,'2015-07-29 12:12:44','2015-07-29 12:12:44',NULL),(36,1,0.10,35,4,'2015-07-30 01:55:16','2015-07-30 01:55:16',NULL),(37,1,0.10,36,4,'2015-07-30 03:01:49','2015-07-30 03:01:49',NULL),(38,1,0.10,37,4,'2015-07-30 03:12:24','2015-07-30 03:12:24',NULL),(39,1,0.10,38,4,'2015-07-30 03:27:25','2015-07-30 03:27:25',NULL),(40,2,0.10,39,4,'2015-07-30 09:18:52','2015-07-30 09:18:52',NULL),(41,1,0.10,40,4,'2015-07-30 09:24:28','2015-07-30 09:24:28',NULL),(42,1,0.10,41,4,'2015-07-30 09:25:43','2015-07-30 09:25:43',NULL),(43,1,0.10,42,4,'2015-07-30 09:36:02','2015-07-30 09:36:02',NULL),(44,1,0.10,43,4,'2015-07-31 12:55:14','2015-07-31 12:55:14',NULL),(45,1,0.10,44,4,'2015-07-31 16:06:21','2015-07-31 16:06:21',NULL),(46,1,0.10,45,4,'2015-08-02 05:12:23','2015-08-02 05:12:23',NULL),(47,1,0.10,46,4,'2015-08-02 05:23:36','2015-08-02 05:23:36',NULL),(48,1,0.10,47,4,'2015-08-03 14:43:46','2015-08-03 14:43:46',NULL),(49,1,0.10,48,4,'2015-08-04 07:22:11','2015-08-04 07:22:11',NULL),(50,1,0.10,49,4,'2015-08-04 07:23:52','2015-08-04 07:23:52',NULL),(51,1,0.10,50,4,'2015-08-04 07:26:02','2015-08-04 07:26:02',NULL),(52,1,0.10,51,4,'2015-08-04 10:54:06','2015-08-04 10:54:06',NULL),(53,1,0.10,52,4,'2015-08-04 11:04:27','2015-08-04 11:04:27',NULL),(54,1,0.10,53,4,'2015-08-04 11:06:48','2015-08-04 11:06:48',NULL),(55,1,0.10,54,4,'2015-08-04 11:09:53','2015-08-04 11:09:53',NULL),(56,1,0.10,55,4,'2015-08-04 15:38:13','2015-08-04 15:38:13',NULL),(57,1,0.10,56,4,'2015-08-05 03:23:58','2015-08-05 03:23:58',NULL),(58,1,0.10,57,4,'2015-08-05 03:53:24','2015-08-05 03:53:24',NULL),(59,1,238.00,58,2,'2015-08-06 04:01:30','2015-08-06 04:01:30',1),(60,1,1.00,59,4,'2015-08-11 09:25:13','2015-08-11 09:25:13',NULL),(61,1,1.00,60,4,'2015-08-11 09:26:25','2015-08-11 09:26:25',NULL),(62,1,1.00,61,4,'2015-08-13 04:56:21','2015-08-13 04:56:21',NULL),(63,1,1.00,62,4,'2015-08-22 07:07:23','2015-08-22 07:07:23',NULL),(64,1,1.00,63,4,'2015-08-22 07:15:31','2015-08-22 07:15:31',NULL),(65,10,96.00,64,21,'2015-08-25 04:58:51','2015-08-25 04:58:51',NULL),(66,1,238.00,65,2,'2015-08-25 12:42:19','2015-08-25 12:42:19',1),(67,1,102.00,66,20,'2015-08-25 13:58:18','2015-08-25 13:58:18',NULL);
/*!40000 ALTER TABLE `orders_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `article` text COLLATE utf8_unicode_ci,
  `cover_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `recommend` tinyint(1) DEFAULT NULL,
  `on_sale` tinyint(1) DEFAULT NULL,
  `price` decimal(8,2) DEFAULT NULL,
  `storage` int(11) DEFAULT NULL,
  `sales` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `channel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_rails_718105988b` (`owner_id`) USING BTREE,
  FULLTEXT KEY `fulltext_index` (`name`,`description`,`article`),
  CONSTRAINT `fk_rails_afb92c238b` FOREIGN KEY (`owner_id`) REFERENCES `groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'西双版纳小耳猪','凑单满额订','<p><img alt=\"\" src=\"http://www.tenhs.com/resources/images/pig.jpg\"><br></p><p>小耳猪，俗称版纳小耳猪、僾尼猪、细骨猪、小香猪等。是我国优良的地方品种之一，为云南省特有，主产于西双版纳等地区；是本地少数民族（傣、僾尼、基诺、哈尼等民族）由本土野猪驯化而来的纯原生本地品种，从东汉至今已有2000多年的历史。</p><p>不同于其他品种的猪，小耳猪生长速度慢，从出生培育到出栏需要10—12个月的时间，出栏体重40-60公斤/头；小耳猪具有皮薄骨细，肉质鲜嫩，口感香糯等特点。瘦肉肌纤维细腻、鲜嫩，色泽润红、油亮，缩水率3-5%；肥肉厚实、白净；鲜肉吃起来鲜、嫩、香、糯，地道的猪肉香味。小耳猪不饱和脂肪酸是普通猪肉的3倍，胆固醇低（46毫克/100克），富含ω—3脂肪酸，具有调节人体血脂的功效。</p><p><img alt=\"\" src=\"http://www.tenhs.com/resources/images/pig1.jpg\"><br></p><p><img alt=\"\" src=\"http://www.tenhs.com/resources/images/pig2.jpg\"><br></p>','http://uploads.tenhs.com/images/20150808/4b45b796-3db7-4592-85e1-547e1099ec01.png',1,'2015-05-28 07:21:58','2015-08-07 16:40:33',0,1,298.00,10,0,0,'0',1),(2,'“有机盒子”果蔬健康搭配5.5公斤／盒','有机绿色蔬菜','<p><img alt=\"\" src=\"http://www.tenhs.com/resources/images/box.jpg\"><br></p><p>每周三统一配送</p><p>次卡238元，月卡868元，年卡9788元</p><p>搭配有机蔬菜8种（云南有机产地直供），水果2种（时令进口水果）</p><p>环保卫士：“有机盒子\"采用云南手工藤编筐，可以保持水果蔬菜的自然新鲜，藤编筐循环利用，随货物留下需收取押金60元，并由拾惠社负责上门回收。</p><p><img alt=\"\" src=\"http://www.tenhs.com/resources/images/box1.jpg\"><img alt=\"\" src=\"http://www.tenhs.com/resources/images/box2.jpg\"><br></p>','http://uploads.tenhs.com/images/20150808/c3f4e241-b965-4c37-b70e-7255ed8ba82d.png',1,'2015-05-28 07:24:42','2015-08-07 16:39:54',0,1,238.00,100,0,0,'0',1),(3,'云南小粒咖啡树认养等','定制产品','<p><img alt=\"\" src=\"http://www.tenhs.com/resources/images/coffee.jpg\"><br></p><p>299元／棵（年）</p><p>一棵咖啡树每年约可结果3-5公斤咖啡果实</p><p>预期收获：约750克～1000克咖啡成品，至少可冲80杯咖啡，每杯花费仅3.7元</p><p>定制专属服务：2（爱）9（久）9（久）挂牌认证、定期成长反馈，</p><p>\r\n可亲自收获、参观加工烘培，个性专属成品包装邮寄到家</p><p>（另有进口家用咖啡机低价直采，可向客服咨询）</p><p><img alt=\"\" src=\"http://www.tenhs.com/resources/images/coffee1.jpg\"><br></p><p><img alt=\"\" src=\"http://www.tenhs.com/resources/images/coffee2.jpg\"><br></p>','http://uploads.tenhs.com/images/20150808/765667af-bd08-4abd-b0ce-fa2e237ade4a.png',1,'2015-05-28 07:26:21','2015-08-07 16:40:11',0,1,299.00,10,1,0,'0',1),(4,'补差价','补差价','<p>本商品用于补差价，请与卖家联系后再购买。</p>','http://uploads.tenhs.com/images/20150702/20e225c2-c172-45cb-ac9b-a2f0d051d316.png',1,'2015-07-02 06:31:04','2015-08-22 07:15:31',0,1,1.00,100000000,37,0,'0',0),(5,'澳大利亚布姆兰干红','BOOMERANG','<p><img src=\"http://uploads.tenhs.com/images/20150805/c3b31dd0-1fa1-42c0-8ee4-b38fd3084634.png\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/675739e5-6fd5-42d4-9e39-481a9fb48005.jpg\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/ace6776b-36b2-4e2b-8505-8cf110547dde.jpg\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/046f764a-b912-4d05-8bc0-06c29a021e7d.jpg\"></p>','http://uploads.tenhs.com/images/20150805/60d16ca9-5adb-4cbf-8762-6a28cd340f7e.png',1,'2015-08-05 03:49:45','2015-08-11 02:04:10',0,0,96.00,100,0,1,'1',0),(6,'澳大利亚香萃提汽泡酒','PATRITTI','<p><br></p><p><img src=\"http://uploads.tenhs.com/images/20150805/b65e1fef-85db-4cff-bcf8-dc83743d6279.png\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/f7807080-9141-4779-8cc4-4e38dccad6eb.png\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/888258b9-dc26-4554-8d72-4f164bae9cf6.png\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/7751768e-9473-4e1c-89ab-11e5f58ba1a1.jpg\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/7766e59f-64a7-4168-b11c-9584944a2989.jpg\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/18e887e2-b0b0-46a2-8836-5fb46dbcde2e.jpg\"></p>','http://uploads.tenhs.com/images/20150805/8fc9b282-3b33-4a13-8892-5f89440e0d97.png',1,'2015-08-05 11:53:12','2015-08-07 16:00:28',0,1,68.00,300,0,0,'1',0),(7,'澳大利亚巴罗莎干红','PATRITTI','<p><img src=\"http://uploads.tenhs.com/images/20150805/4961a7c3-17fd-43ec-ae74-cc611704d2c6.png\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/b5238930-cdf0-4a27-bef5-482d3f32f6b1.jpg\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/e807cfad-d730-405e-8755-5c4e62d0cc41.jpg\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/237af0d9-5919-4770-a51d-f8f304cdfc2c.jpg\"></p>','http://uploads.tenhs.com/images/20150805/0f56081e-c27f-43a4-acb9-9f82c7cb6068.png',1,'2015-08-05 11:58:24','2015-08-07 16:00:37',0,1,278.00,100,0,0,'1',0),(8,'法国圣皮尔干红','EXCELLENCE DE CHATEAU SAINT PERE COSTIERES DE NIMES AOC','<p><img src=\"http://uploads.tenhs.com/images/20150805/82a46227-63ad-4079-a390-516ed8665919.png\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/e8ba3d42-70fc-4711-a90e-1aa4362a3c49.jpg\"><br></p><p><img src=\"http://uploads.tenhs.com/images/20150805/e8bc1817-a5d5-4487-9c1a-194930186ca2.jpg\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/51c3c584-a273-4d5c-8728-cc2758350792.jpg\"></p>','http://uploads.tenhs.com/images/20150805/f8f3a6de-ccf3-4570-b7a4-903fd84b8806.png',1,'2015-08-05 12:02:18','2015-08-07 16:00:56',0,1,155.00,100,0,0,'1',0),(9,'法国香卡隆干红','DUC DE GARENNE  法国原装进口','<p><img src=\"http://uploads.tenhs.com/images/20150805/2d3a046b-ff76-4d16-a367-24f50e076e1f.png\" unselectable=\"on\"></p><p>产品介绍：</p><p>原产国：法国</p><p> 产区：波尔多埃罗省</p><p>类型：干红葡萄酒 </p><p> 规格：1瓶*750ML</p><p>保质期：10年 </p><p> 酒精度：12%</p><p>储存方式：避光、横放 </p><p>最佳品尝温度：17℃</p><p>酒评：馥郁的黑莓果香，些许辛辣栖息，口感柔和充盈，均衡协调。</p><h2>法国原装原瓶进口，法定产区酒，价格劲爆，你值得拥有............................</h2><h2>完美PK任何国产红酒，值得您试一试！！</h2><p><img src=\"http://uploads.tenhs.com/images/20150805/2e36b53f-026e-4aa0-9963-9aac4e904986.jpg\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/38f9a800-2390-443c-8969-78c8f2ffb02d.jpg\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150805/a04156c7-8845-4f13-865b-3101a67efcb5.jpg\" unselectable=\"on\"></p>','http://uploads.tenhs.com/images/20150805/3cd4c1f5-af1a-4b24-985b-2e6bf8bcd473.png',1,'2015-08-05 12:09:31','2015-08-11 01:19:52',0,1,65.00,100,0,0,'1',0),(10,'云南生态鲜花饼','每盒10个，每个30G','<p><img src=\"http://uploads.tenhs.com/images/20150806/168016b8-d47e-4796-b43b-644bbc6a23c5.png\" unselectable=\"on\"></p><p>鲜花饼是以云南特有的食用玫瑰花入料的酥饼，是具有云南特色的云南经典点心代表。</p><p>鲜花饼在云南当地烘焙品牌大都均有销售。</p><p>鲜花饼也是中国四大月饼流派滇式月饼的经典代表之一。</p><p>鲜花饼的制作缘起300多年前的清代。由上等玫瑰花制得的鲜花饼，因其特色风味历为宫廷御点，深得乾隆皇帝喜爱。近代滇式鲜花饼就是1945年昆明冠生园生产的鲜花饼为起源，当年在昆明的西坝昆明冠生园还专门开辟一块地种植使用鲜花用来加工鲜花饼和玫瑰糖。</p><p>主要食材</p><p>面粉、玫瑰，玉兰，菊花。冰糖、白糖、芝麻、花生、核桃仁、枣泥、猪边生油。</p><h3 style=\'font: 500 18px/1.1 \"Roboto Regular\", Arial, sans-serif; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; margin-top: 20px; margin-bottom: 10px; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>【价格与包装规格】</h3><h3>礼品纸盒装，每盒分装5小袋，每盒10个。</h3><h2> </h2><h2>推广特惠产品，一盒也包邮哦，机会难得，亲，千万别错过。。。。。。。</h2><p><img src=\"http://uploads.tenhs.com/images/20150806/6669365c-5174-4fa5-8dba-139077a6af9d.png\" unselectable=\"on\"></p>','http://uploads.tenhs.com/images/20150805/92727656-7b1f-44ac-8b2a-31a251c0f92a.png',1,'2015-08-05 12:12:28','2015-08-11 01:11:31',0,1,28.80,100,0,0,'1',1),(11,'生态高原火烧牦牛肉','私房定制','<p><img src=\"http://uploads.tenhs.com/images/20150805/e58f1021-e9ac-42cf-a346-1470044e0c1f.JPG\"></p><h3>       啊三孃手撕干巴产自恒春之都--大美临沧，精选高山放养黄牛肉，牛腿处肉质优良、肉纤维较长的腿部肌肉。（每头牛后腿瘦肉仅能制成手撕牛肉10余斤）</h3><h3>      独家秘方腌制。高温炭火烘烤。纯手工舂开牛肉、手撕牛肉。根据个人口味秘制配方，以云南麻辣口味最为独特。有香酥、原味等多种口味供您选择。保证原汁原味，您所品尝到的是牛肉天然的味道。</h3><h3>（由于没有任何防腐剂和添加剂，提前2天预定，为您制作最新鲜的牛干巴）</h3><p><img src=\"http://uploads.tenhs.com/images/20150805/d4609fdb-6c6d-463a-bb32-093d26b09556.JPG\" style=\"\"></p><p><strong>制作流程</strong></p><p>1：牛肉切条，去筋去膘；</p><p>2：腌制；</p><p><img src=\"http://uploads.tenhs.com/images/20150805/7acf80ff-da8c-4f44-b302-977d297cd33d.JPG\"></p><p>3：炭火烘烤；</p><p><br></p><p>4：风干；</p><p><img src=\"http://uploads.tenhs.com/images/20150805/bf66797d-1d19-41ac-abb7-c3f20406af69.JPG\"></p><p>5：把烘烤好的牛肉入锅回软；</p><p>6：手工舂开（麻辣口味的需手工撕开，让佐料更均匀的和牛肉融合）；</p><p>7：舂好、撕好的牛肉装盘进烤箱再次烘烤；</p><p>8：常温装袋真空。</p><p><img src=\"http://uploads.tenhs.com/images/20150810/2bc59e49-88dd-4b89-b59f-be89939af803.JPG\"></p>','http://uploads.tenhs.com/images/20150810/7f0561a9-a461-47f7-a410-27aef8509501.JPG',1,'2015-08-05 12:22:39','2015-08-10 08:53:10',0,1,60.00,300,0,0,'1',1),(12,'生态高原火烧驴肉','私房定制','<p><img src=\"http://uploads.tenhs.com/images/20150806/66aa19b9-cc17-4635-902e-17ece1b63548.JPG\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/48e68d8e-b782-4377-8bd5-469246e0ccbb.JPG\"></p><p><br></p><p><img src=\"http://uploads.tenhs.com/images/20150806/30c3271c-0660-4634-9c85-05a1d4e90623.JPG\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/b427534c-6ad1-4293-b89c-3fb7eef02bbf.JPG\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/1c513923-df7b-43c4-b9ef-4b72d598b59f.JPG\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/f745554e-0f80-428a-bdb9-3b4938d0dfab.JPG\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/5827ca97-400c-4ecc-a5ff-9e16874e7993.JPG\"></p>','http://uploads.tenhs.com/images/20150806/88f5d142-a00d-495c-aa28-87fe55af19da.png',1,'2015-08-06 02:49:08','2015-08-06 02:50:14',0,1,51.00,297,0,0,'1',1),(13,'云南玫瑰花糖','天然玫瑰','<p><img src=\"http://uploads.tenhs.com/images/20150806/c7471970-4ee6-4897-9a3f-c833d50329cb.png\" unselectable=\"on\"></p><p>现采玫瑰花手工自制玫瑰花馅、玫瑰花糖，可用于包子馅、鲜花饼馅、抹面包酱、泡水喝等等，口感都非常好，甜而不腻！</p><p><strong>功效</strong></p><p>促进新陈代谢。减轻女性生理期的疼痛，养颜美容。食用玫瑰中的单宁成分能有效对抗电脑辐射、抗紫外线，增进血液循环，防止便秘，改善皮肤干燥，有助于消化、消脂，有效缓解口臭，疏解感冒咳嗽，软化心脑血管，舒缓压力，调节心情。</p><p><img src=\"http://uploads.tenhs.com/images/20150806/7e57a354-b59b-4693-aa19-7ada291d810c.JPG\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/3d5665d4-03f3-436a-a7a8-56e48cf6b80b.JPG\" unselectable=\"on\"></p><h4 style=\'font: 500 18px/1.1 \"Roboto Regular\", Arial, sans-serif; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; margin-top: 10px; margin-bottom: 10px; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>【价格与规格】</h4><p style=\'font: 500 18px/1.1 \"Roboto Regular\", Arial, sans-serif; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; margin-top: 10px; margin-bottom: 10px; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>秘制玫瑰花糖价格：60.00元/KG</p><h4 style=\'font: 500 18px/1.1 \"Roboto Regular\", Arial, sans-serif; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; margin-top: 10px; margin-bottom: 10px; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>以100G为基础销售单位，每拍一份默认为100G，若您需要超过100G，请您到购物车点“+\"添加份数，亲，300G包邮哦~~~~~~~~~~~</h4>','http://uploads.tenhs.com/images/20150806/56b22f57-634c-412a-8ae2-a0547b903311.png',1,'2015-08-06 03:00:58','2015-08-11 02:35:25',0,1,6.00,1000,0,0,'1',1),(14,'云南玫瑰花茶','特级','<p><img src=\"http://uploads.tenhs.com/images/20150806/8a50b363-a07b-4b0d-b718-e4851b197bcc.JPG\" unselectable=\"on\"></p><p><strong>功效</strong></p><p>玫瑰花茶性质温和，降火气，可调理血气，促进血液循环，养颜美容。且有消除疲劳，愈合伤口，保护肝脏胃肠功能，长期饮用亦有助于促进新陈代谢。很多人由于不了解其作用而忽视了它。其实，玫瑰花是很好的药食同源的食物，女性平时常用它来泡水喝，有很多好处，尤其是月经期间情绪不佳、脸色黯淡，甚至是痛经等症状，都可以得到一定的缓解。女性在月经前或月经期间常会有些情绪上的烦躁，喝点玫瑰花茶可以起到调节作用。</p><p><img src=\"http://uploads.tenhs.com/images/20150806/44a231d0-facf-44c2-8d78-2bc246571a63.JPG\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/fbfcee41-0221-4aa2-8b24-38d17003a0ce.JPG\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/2b07a96e-45a3-4975-b033-fbf5fcd2eb64.JPG\" unselectable=\"on\"></p><h4 style=\'font: 500 18px/1.1 \"Roboto Regular\", Arial, sans-serif; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; margin-top: 10px; margin-bottom: 10px; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'> </h4><h4 style=\'font: 500 18px/1.1 \"Roboto Regular\", Arial, sans-serif; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; margin-top: 10px; margin-bottom: 10px; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>【价格与规格】</h4>特级玫瑰话茶价格：200.00/KG<h4 style=\'font: 500 18px/1.1 \"Roboto Regular\", Arial, sans-serif; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; margin-top: 10px; margin-bottom: 10px; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>以100G为基础销售单位，每拍一份默认为100G，若您需要超过100G，请您到购物车点“+\"添加份数，亲，300G包邮哦~~~~~~~~~~~</h4>','http://uploads.tenhs.com/images/20150806/01a5a45a-6f97-49fb-9124-c4b83fcd4543.png',1,'2015-08-06 03:06:19','2015-08-11 02:33:01',0,1,20.00,100,0,0,'1',1),(15,'食用玫瑰花瓣','紫枝玫瑰，天然美容养身佳品。','<p><img src=\"http://uploads.tenhs.com/images/20150806/f57be283-2642-4650-8491-07c99704772c.JPG\" unselectable=\"on\"></p><p>【美容价值】</p><p>玫瑰花含丰富的维生素A、C、B、E、K，以及单宁酸，能改善内分泌失绸，对消除疲劳和伤口瘀合也有帮助。调气血，调理女性生理问题，促进血液循环，美容，调经，利尿，缓和肠胃神经，防皱纹，防冻伤，养颜美容。身体疲劳酸痛时，取些来按摩也相当合适。</p><p>【药用价值】</p><p>玫瑰为蔷薇科落叶灌木。其花色鲜艳，花姿优美，香气浓郁，以象征友谊和爱情而著称。另外，玫瑰花含有人体所需的18种氨基酸和多种微量元素．具有通经活血、美容养颜等功效。国内外医药专家研究表明，玫瑰花对治疗心血管疾病具有特效。故玫瑰花有药膳之功，是佳肴中的珍品。花入药，功能理气活血、疏肝解郁，主治肝胃气痛、食少呕恶、月经不调、跌打损伤等症。</p><p>【食用方法】</p><p>云南特色礼仪接待菜肴：玫瑰煎鸡蛋（新鲜玫瑰花瓣300G，鸡蛋三个）</p><p>制作方式：1、将新鲜玫瑰花洗净并切碎。</p><p>                  2、将鸡蛋打入碗内并打散。</p><p>                  3、将切好的玫瑰花瓣混入打散的鸡蛋中调匀，加入适当精盐。</p><p>                  4、将混合好的原料倒入油锅，待鸡蛋呈现金黄色时起锅即可。</p>更多新鲜玫瑰花做法请     百度一下。。。。。。。<p>【价格与运费】</p><h4 style=\'font: 500 18px/1.1 \"Roboto Regular\", Arial, sans-serif; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; margin-top: 10px; margin-bottom: 10px; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>以100G为基础销售单位，每拍一份默认为100G，若您需要超过100G，请您到购物车点“+\"添加份数，亲，500G包邮哦~~~~~~~~~~~</h4><h3><br class=\"Apple-interchange-newline\">新鲜食用玫瑰价格：60.00/KG</h3><p><img src=\"http://uploads.tenhs.com/images/20150806/a72155f1-4502-449f-97aa-81c1ef12e486.JPG\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/bc3073d8-ac92-498b-a81f-fe30149bc868.JPG\" unselectable=\"on\"></p>','http://uploads.tenhs.com/images/20150806/a0b3f759-7714-4596-aebe-82828bd543b3.JPG',1,'2015-08-06 03:12:11','2015-08-11 01:50:39',0,1,6.00,100,0,0,'1',1),(16,'云南丽江天然玛卡干果','特级玛卡','<p><img src=\"http://uploads.tenhs.com/images/20150809/64f88c7f-9ba3-4108-ab79-64a7ae55cfa6.JPG\" unselectable=\"on\"></p><h2>玛卡（学名：Lepidium meyenii Walp.），（西班牙语：Maca）。是原产南美洲安第斯山脉的一种十字花科植物。叶子椭圆，根茎形似小圆萝卜，可食用，是一种纯天然食品，营养成份丰富，有\"南美人参\"之誉。玛卡的下胚轴可能呈金色或者淡黄色、红色、紫色、蓝色、黑色或者绿色。淡黄色的根最常见，形状、味道也最好。玛卡富含高单位营养素，对人体有滋补强身的功用。玛卡原产高海拔山区，适宜在高海拔、低纬度、高昼夜温差、微酸性砂壤、阳光充足的土地中生长；分布于南美安第斯山脉，人工种植于秘鲁中部和南部，中国的云南和新疆等地区，有较大面积的适种土地。</h2><h3>拾惠社 精心为您挑选了云南高海拔特级生态玛卡</h3><h4> </h4><h4>根据药用价值、颜色形态不同，所以价格也不同：</h4><h4>黑玛卡干果：380.00/KG                </h4><h4>紫玛卡干果：260.00/KG</h4><h4>黄玛卡干果：170.00/KG</h4><h4> </h4><h4>拾惠社为您提供的玛卡均为云南高原无污染有机田地长周期种植出来的玛卡，种植过程模拟野生环境培育，绝不使用农药化肥，没有农药残留，请您放心购买。</h4><p>黑玛卡，也称黑玛咖、黑金根。是一种生长在云南丽江高原山区的神秘野果，别名为甜菜根或秘鲁人参，为十字花科(Cruciferae)独荇菜属。多生在人迹罕见、寸草不生的贫瘠高原，很难被人发现。</p><p>黑玛卡是玛卡中营养最好，也是最少见的野生品种。玛卡主要有白色、黄色、紫色和黑色四种颜色，颜色越深表示品质越好。被誉为\"玛卡之中的黑钻石\"，\"玛卡之王\"。有提高生育的功效，传说是纳西族女子陪嫁时的必备品，纳西族人为它取名为\"纳涵珂\"，意为\"纳西之根\"，翻译成中文就是\"黑金根\"</p><p>黑金根是云南丽江特产的一种玛卡，在云南当地非常盛行。它外表黝黑，切开后内里金黄，独生长于玉龙雪山海拔3500多米高的区域，得天独厚的生长环境使得黑金根的营养价值远高于任何一种玛卡，甚至高于秘鲁原产的玛卡。丽江黑金根属于玛卡中的精品，自然产量也十分稀少，科学研究表明，黑金根中含有的芥子油苷、玛卡酰胺和玛卡烯，有提高男性、延缓衰老、提高免疫力、改善睡眠等滋补强身的功效，在国内外保健食疗领域地位愈见显赫。</p><h4> </h4><h4>销售规格：以100G为基础销售单位，每拍一份默认为100G，若您需要超过100G，请您到购物车点“+\"添加份数，亲，300G包邮哦~~~~~~~~~~~</h4><p><img src=\"http://uploads.tenhs.com/images/20150806/d4611066-a2b7-4502-8425-72867ce19d59.JPG\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/922de17b-3586-4cc1-8798-5bd48bd99192.JPG\" unselectable=\"on\"></p>','http://uploads.tenhs.com/images/20150806/bb501814-c191-49bf-8d4a-17d099e2c198.png',1,'2015-08-06 03:19:26','2015-08-10 09:51:37',0,1,17.00,300,0,0,'1',1),(17,'云南文山三七','干散精品','<h2>三七具有国家批准实验的保健品24种功能中的19种功能——免疫调节，延缓衰老，改善记忆。促进生长育，抗疲劳。耐缺氧，抗突变。仰制肿瘤，调节血脂，改善性功能，调节血糖，改善睡眠，改善营养贫血，保护化学性肝损损伤，美容，清咽润喉，调节血压。三七所含成分对血液系统，心脑血管系统，中枢神经系统，代谢系统具有良好的生理调节作用，是保健，治疗心脑血管疾病的最佳天然药物之一。</h2><h3>三七的功效与食法三七还能双向调节人体机能， 增强机体的应激能力和高机 体对不良环境的适应能力，是疗补功能兼备的药食同源植物药。</h3><h3> [三七主要功效与作用]：</h3><p> 1、扩张血管、降低血压，改善微循环，增加血流量，预防和治疗心脑组织缺血、缺氧症；</p><p> 2、促进蛋白质、核糖核酸（RNA）、脱氧核糖核酸（DNA）合成，强身健体；</p><p> 3、促进血液细胞新陈代谢，平衡调节血液细胞；</p><p> 4、双向调节中枢神经，提高脑力，增强学习和记忆能力；</p><p> 5、增强机体免疫功能，抗肿瘤；</p><p> 6、止血、活血化瘀；</p><p> 7、保肝、抗炎；</p><p> 8、延缓衰老；</p><p> 9、双向调节血糖、降低血脂、胆固醇、抑制动脉硬化。</p><h3> [三七的主要适用人群]：</h3><p> 1、办公室白领，工作压力大，使用之后减轻压力。预防心血管病的发生。</p><p> 2、在校学生，很多学生晚上精力充足，晚上睡不着，吃安眠药是不可取的。</p><p> 3、经常做着不动的人，有的人在办公室对电脑一天都不动，这样会引会高血脂和心血管疾病。</p><p> 4、平常天天使用纯净水，这是不合理的，使用三七花泡水可以补充其它的一些人体必须元素。</p><p> 5、60岁以上的老年人，具有高血压、高血脂、失眠等病有很好的疗效。</p><h3> [用法与用量]：</h3><p> 1、跌打损伤等各种出血症，直接用三七撒布伤口即可，伤口较大的，撒布三七后，再用消毒纱布加压包扎，可迅速止血。</p><p> 2、三七、三七片或三七胶囊，一次2克，每日2－3次，温开水或温米汤送服。可治疗各种体内出血，如胃出血、鼻血、吐血、便血、尿血、子宫功能性出血、皮下出血、眼出血及脑血管出血。</p><p> 3、三七、三七片或三七胶囊一次2克，每日2－3次，温开水或温酒送服。可治疗血瘀而致的月经不调、闭经、痛经及产后恶露不停，小腹瘀滞疼痛等。</p><p> 4、适量三七与适量蜂蜜调和成糊状，直接敷面10－20分钟，具有活血润肤、抗衰老的功用，长期敷面可使皮肤光洁、细嫩。（敷面期间，再用蜂蜜水内服三七效果更佳）。</p><p> 5、三七、三七片或三七胶囊一次2克，每日2－3次，温开水或蜂蜜水送服。可治疗支气管扩张症、肺结核和肺脓肿等引起得咯血。具有止血、镇咳、祛痰及镇痛作用。</p><p><span></span>6、三七、三七片或三七胶囊一次2克，每日2－3次，温开水送服。能使心肌耗氧量减少，有助于减轻心脏负担，故能治疗冠心病和心绞痛。</p><p> 7、三七、三七片或三七胶囊一次2克，每日2－3次，温开水送服。能扩张血管、降低血压以及治疗脑动脉硬化，以及因血脂和胆固醇增高而导致的疾病；三七并具有抗肿瘤抗</p><h3>【价格与规格】</h3><h3>30头：450.00/KG  (每500G在30头以内)</h3><h3>40头：370.00/KG  (每500G在40头以内)</h3><h3>60头：280.00/KG  (每500G在60头以内)</h3><h4 style=\'font: 500 18px/1.1 \"Roboto Regular\", Arial, sans-serif; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; margin-top: 10px; margin-bottom: 10px; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>以100G为基础销售单位，每拍一份默认为100G，若您需要超过100G，请您到购物车点“+\"添加份数，亲，300G包邮哦~~~~~~~~~~~</h4><p><br> </p><p><img src=\"http://uploads.tenhs.com/images/20150806/2b8597f7-e084-48fe-bfc3-8e01cdc13163.png\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/61fbbd9a-268e-4b33-a777-7e4c87e90e99.jpg\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/c180ac94-cf69-4abd-9179-9c72b8f65460.jpg\" unselectable=\"on\"></p><p><br></p>','http://uploads.tenhs.com/images/20150806/cc49bd6d-7e07-4969-aaf7-6033ee7f76e3.png',1,'2015-08-06 03:26:29','2015-08-10 09:39:06',0,1,28.00,300,0,0,'1',1),(18,'石斛','益胃生津，滋阴清热','<p><img src=\"http://uploads.tenhs.com/images/20150809/04c923cc-6517-4d75-b234-6040ec857fee.jpg\" unselectable=\"on\"><br></p><p><strong>石斛的作用</strong></p><p>胃阴虚及热病伤津证。本品长于滋养胃阴,生津止渴，兼能清胃热。主治热病伤津，烦渴、舌干苔黑之证，常与天花粉、鲜生地、麦冬等品同用，如《时病论》清热保津法。治胃热阴虚之胃脘疼痛、牙龈肿痛、口舌生疮可与生地、麦冬、黄芩等品同用。</p><p>肾阴虚证。本品又能滋肾阴，兼能降虚火，适用于肾阴亏虚之目暗不明、筋骨痿软及阴虚火旺，骨蒸劳热等证。肾阴亏虚，目暗不明者，常与枸杞子、熟地黄、菟丝子等品同用，如石斛夜光丸(《原机启微》)。肾阴亏虚，筋骨痿软者，常与熟地、山茱萸、杜仲、牛膝等补肝肾、强筋骨之品同用。肾虚火旺，骨蒸劳热者，宜与生地黄、枸杞子、黄柏、胡黄连等滋肾阴、退虚热之品同用。</p><p><strong>石斛的功效</strong></p><p> 秦汉时期的《神农本草经》记载铁皮石斛\"主伤中、除痹、下气、补五脏虚劳羸瘦、强阴、久服厚肠胃\"；成书于一千多年前的道家医学经典《道藏》将铁皮石斛列为\"中华九大仙草\"之首；李时珍在《本草纲目》中评价铁皮石斛\"强阴益精，厚肠胃，补内绝不足，平胃气，长肌肉，益智除惊，轻身延年\"；民间称其为\"救命仙草\"现代的铁皮石斛的茎能够清热生津，消炎止痛，清润喉咙，对治疗嗓音嘶哑有很好的疗效。石斛具有良好的抗疲劳，耐缺氧的作用。药房里面的铁皮石斛，品类众多，价格便宜，往往是以水草充当，国内只有少数几个大品牌能够买到真正的铁皮石斛，以福临门铁皮石斛和同仁堂这两个老品牌为代表，最为正宗。同仁堂价格最贵，包装较为漂亮，适合用于送礼。</p><p><strong>食疗价值</strong></p><p> 兰科草本植物环草石斛、马鞭石斛等多种石斛的茎。产于西南和广东、广西、安徽等地。多在秋季采收，干燥切段，或鲜用。</p><p> [性能]味甘，性微寒。能养阴清热，益胃生津。</p><p> [参考]含石斛碱等生物碱，粘液质、淀粉等。</p><p> 有一定解热镇痛作用;能促进胃液分泌，助消化;有增强新陈代谢、抗衰老等作用。</p><p> [用途]用于热伤津液，低热烦渴，舌红少苔;胃阴不足，口渴咽干，呕逆少食，胃脘隐痛，舌光少苔;肾阴不足，视物昏花。</p><p><strong>石斛的食用方法</strong></p><p>石斛酱鸭是平时常见的一种食用方法。还可以泡酒。炖肉可以当辅料添加。</p><p>炖食猪肉、鸡肉时，可加入10-20克石斛，经常食用，可改善贫血症状。</p><p>煮水当茶喝，而不是用开水泡着。通常，石斛一次要煮6~10分钟，注意要用文火，煮沸时间短，水开后要马上喝，边喝边添水，石斛水颜色最深的时候是营养最丰富的时候，这个时候的水一定不要浪费。通常石斛水会经历一个由淡到浓再转淡的过程，余味也很绵长。</p><p>治疗肺结核，可将鸭内洗净炖30分钟后加入石斛、百合，再煮15分钟，加盐，味精适量即成。也可将石斛用布包好，与粳米、猪瘦肉一同入锅，加水适量，旺火烧开后转文火煮成稀粥，加食盐调味后食用，同样可收到治疗作用。</p><p style=\'font: 15px/30.79px \"Roboto Regular\", Arial, sans-serif; margin: 0px 0px 10px; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>【价格与运费】</p>精品特效石斛价格：580.00/KG<h4 style=\'font: 500 18px/1.1 \"Roboto Regular\", Arial, sans-serif; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; margin-top: 10px; margin-bottom: 10px; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>以100G为基础销售单位，每拍一份默认为100G，若您需要超过100G，请您到购物车点“+\"添加份数，亲，300G包邮哦~~~~~~~~~~~</h4><p><img src=\"http://uploads.tenhs.com/images/20150806/882c2b8e-301e-4a29-adda-cb8c98f93113.jpg\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/b81f7d5c-13ef-4734-a891-b41b765c3e5b.jpg\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150806/1c854a06-35f8-47aa-bd87-a2da4e8c8b69.jpg\" unselectable=\"on\"></p>','http://uploads.tenhs.com/images/20150806/7a235fe1-6542-49c6-b9f2-3107562fa3e5.png',1,'2015-08-06 03:31:09','2015-08-11 01:53:32',0,1,58.00,100,0,0,'1',1),(19,'辣木籽','植物中的钻石','<p><img src=\"http://uploads.tenhs.com/images/20150806/a8930621-4bcb-449b-a633-bbbc98d11d9b.jpg\" unselectable=\"on\"></p><p>辣木籽，白花菜目辣木科，又称鼓槌树。多年生热带落叶乔木。在全世界约有14个品种。辣木枝叶美丽，花黄白色，有香味，通常作为观赏树木。种子可榨油，供工业和工艺用。嫩叶和嫩果可食用。花和树皮可供药用。辣木籽保水的本领很厉害，能在极限干旱地区的恶劣环境中生长。辣木籽除少量用于种植之外，大量的用途是用来做生产原料，在食品、医药、保健、化妆品等领域都有着良好的应用价值，如可用于液体净化、提取制造保水、防晒等高档化妆品的活性物质等。</p><p>辣木的种子和叶子中含有丰富的营养成分。孙林晴（L.S. Ching）等人于二零零一年发表，100克印度传统辣木的新鲜叶片中的维他命E含量约为9毫克，干燥叶片中的含量约为16.2毫克。根据计算，只要三汤匙（约25克）的辣木叶干粉 就含有幼儿每日所需270%的维生素A，42%的蛋白质，125%的钙，70%的铁及22%的维生素C。对怀孕和哺乳中的女性而言，辣木叶片和豆荚亦可帮 助本人及胎儿或婴儿维持健康，供给大量的铁质、蛋白质、铜、硫和维他命B。不过，由于辣木本身含有生物碱，高血压、糖尿病患者及孕妇等最好经医师指示后酌量食用。</p><p>辣木叶片、果荚富含多种矿物质、维生素、20种氨基酸、46种抗氧素和36种自然防炎体和矿物质。每100克的辣木中含有的维生素C是柑橘的7倍，铁是菠菜的3倍，维生素A是胡萝卜的4倍，钙质是牛奶的4倍，钾是香蕉的3倍，蛋白质是酸奶的2倍。</p><p style=\'font: 15px/30.79px \"Roboto Regular\", Arial, sans-serif; margin: 0px 0px 10px; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>【价格与运费】</p><p style=\'font: 15px/30.79px \"Roboto Regular\", Arial, sans-serif; margin: 0px 0px 10px; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>天然辣木籽价格：1500.00/KG</p><h4 style=\'font: 500 18px/1.1 \"Roboto Regular\", Arial, sans-serif; color: rgb(119, 119, 119); text-transform: none; text-indent: 0px; letter-spacing: normal; margin-top: 10px; margin-bottom: 10px; word-spacing: 0px; white-space: normal; box-sizing: border-box; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\'>以100G为基础销售单位，每拍一份默认为100G，若您需要超过100G，请您到购物车点“+\"添加份数，亲，100G也包邮哦~~~~~~~~~~~</h4><p><img src=\"http://uploads.tenhs.com/images/20150809/82c67948-1388-4468-9d1e-4d68bfb10995.jpg\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150809/7896eaaa-3586-4bf0-aac6-72dec6c4e9ae.jpg\" unselectable=\"on\"></p><p><img src=\"http://uploads.tenhs.com/images/20150809/b4943f83-bb8f-4e94-90bb-51b57a00de82.jpg\" unselectable=\"on\"></p><br>','http://uploads.tenhs.com/images/20150806/4772d3f5-3b65-4557-ba82-9877922baf4a.JPG',1,'2015-08-06 03:41:20','2015-08-11 02:03:37',0,1,150.00,100,0,0,'1',1),(20,'生态越南野鸡','1.2-1.5千克，整只出售','<p><em></em><em></em><img src=\"http://uploads.tenhs.com/images/20150808/226a73a4-d469-4a8a-9bcc-4fbb1fe74426.jpg\"></p><p>野鸡为历代的皇家贡品，清代乾隆皇帝食后赞叹不已，写下\"名震塞北三千里，味压江南十二楼\"的名句。全国政协副主席叶选平食后评价：\"好看、好吃、有野味\"；著名营养学家于若木也对野鸡的营养成份给予很高的评价。野鸡送人是高档礼品，待客是珍稀野味，还是英国皇室招待国家元首的保留菜肴。正因为如此，每年春节前后，市场上都掀起一股送野鸡的热潮。</p><p>《本草纲目》记载：野鸡补气血，食之令人聪慧，止泻痢，除久病及五脏喘息等。经北京医科大学测定：它含有人体所必需的氨基酸28种之多，其中有多种是人体自身所无法合成的，符合世界卫生组织规定的氨基酸模式。并富含锗、硒、锌、铁、钙等多种人体必需的微量元素，对儿童营养不良、妇女贫血、产后体虚、子宫下垂和胃痛、神经衰弱、冠心病、肺心病等，都有很好的疗效，对人体的滋补功能远远高于久负盛名的甲鱼、鳗鱼等。野鸡中锶和钼的含量比普通鸡高15%，还有防治癌症的作用。</p><p><img src=\"http://uploads.tenhs.com/images/20150808/af7eda8c-b02a-4c54-90e6-677e2781b91e.jpg\"></p><p><img src=\"http://uploads.tenhs.com/images/20150808/575229ab-9c45-4c20-9b5d-b1ac0758ff07.jpg\"></p>','http://uploads.tenhs.com/images/20150808/32f6049c-3a87-4d6e-8bfa-56f6a1c69b58.png',1,'2015-08-07 16:19:38','2015-08-25 13:58:18',0,1,102.00,100,1,0,'0',1),(21,'澳大利亚布姆兰干红','澳洲原装进口原瓶进口','<p><img src=\"http://uploads.tenhs.com/images/20150811/633040ac-3fab-4cd6-89d8-c5db69fd9971.png\"></p><p><img src=\"http://uploads.tenhs.com/images/20150811/1c8de75b-0213-4163-9d3a-7065000cdb77.jpg\"></p>','http://uploads.tenhs.com/images/20150817/698a8433-cb3d-4e91-b177-5dbbe8f15db7.png',1,'2015-08-11 02:23:17','2015-08-25 12:52:58',0,1,96.00,100,0,0,'1',0);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redactor_assets`
--

DROP TABLE IF EXISTS `redactor_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `redactor_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data_content_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data_file_size` int(11) DEFAULT NULL,
  `assetable_id` int(11) DEFAULT NULL,
  `assetable_type` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_redactor_assetable_type` (`assetable_type`,`type`,`assetable_id`),
  KEY `idx_redactor_assetable` (`assetable_type`,`assetable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redactor_assets`
--

LOCK TABLES `redactor_assets` WRITE;
/*!40000 ALTER TABLE `redactor_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `redactor_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20150527084153'),('20150604015512'),('20150630162746'),('20150706015749'),('20150706031814'),('20150706032048'),('20150706034007'),('20150706034413'),('20150706125213'),('20150706125739'),('20150714091350'),('20150730024847'),('20150803012029'),('20150804081434'),('20150807145016'),('20150819120348');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `simple_captcha_data`
--

DROP TABLE IF EXISTS `simple_captcha_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `simple_captcha_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `simple_captcha_data`
--

LOCK TABLES `simple_captcha_data` WRITE;
/*!40000 ALTER TABLE `simple_captcha_data` DISABLE KEYS */;
INSERT INTO `simple_captcha_data` VALUES (132,'19f5abf6a5d3622f76900f82ccb84300714a50ad','KBJM','2015-08-25 13:51:09','2015-08-25 13:51:09'),(133,'51e3ee67daf77dc423873b75b743ccb9925d8856','GCXL','2015-08-25 15:45:15','2015-08-25 15:45:15'),(134,'e3fb251cf0d960a499b30442d48c3d1d5b2fdcf8','MCDH','2015-08-25 15:46:03','2015-08-25 15:46:03'),(135,'fdfc5f5ff011f1441fa4188dc5c25af3a410fb27','QLRE','2015-08-26 02:57:48','2015-08-26 02:57:48'),(136,'4310a2eb0e909810a54fc5c3ca141a4a81a3b2ac','QCUF','2015-08-26 08:48:47','2015-08-26 08:48:47');
/*!40000 ALTER TABLE `simple_captcha_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specifications`
--

DROP TABLE IF EXISTS `specifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `specifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `price` decimal(8,2) DEFAULT NULL,
  `storage` int(11) DEFAULT NULL,
  `sales` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_rails_9b321d46dc` (`product_id`) USING BTREE,
  CONSTRAINT `fk_rails_1758048767` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specifications`
--

LOCK TABLES `specifications` WRITE;
/*!40000 ALTER TABLE `specifications` DISABLE KEYS */;
INSERT INTO `specifications` VALUES (1,'套餐','次卡238元',2,'2015-05-28 07:24:42','2015-08-25 12:42:19',238.00,10,10,0),(2,'套餐','月卡868元',2,'2015-05-28 07:24:42','2015-06-07 14:17:18',868.00,10,0,0),(3,'规格','298元／3公斤',1,'2015-06-06 06:56:11','2015-07-27 03:01:55',298.00,10,1,0),(4,'规格','455元／5公斤 ',1,'2015-06-06 06:56:11','2015-06-07 14:14:23',455.00,10,0,0),(5,'规格','4500元／头（保证50公斤，超出部分白送）',1,'2015-06-06 06:56:11','2015-06-07 14:14:23',4500.00,10,0,0),(6,'套餐','年卡9788元',2,'2015-06-06 07:00:20','2015-06-07 14:17:18',9788.00,10,0,0),(7,'test','支付测试0.1',3,'2015-06-07 14:08:33','2015-06-07 14:13:48',0.10,10,0,1),(8,'abc','abc0.2',3,'2015-06-07 14:09:45','2015-06-07 14:10:23',0.20,10,0,1),(9,'规格','750ml/瓶',5,'2015-08-05 03:49:45','2015-08-05 03:49:45',96.00,100,0,0),(10,'规格','香萃提纯白气泡型葡萄汁',6,'2015-08-05 11:56:00','2015-08-05 11:56:00',68.00,100,0,0),(11,'规格','香萃提纯金气泡型葡萄汁',6,'2015-08-05 11:56:00','2015-08-05 11:56:00',68.00,100,0,0),(12,'规格','香萃提纯黑气泡型葡萄汁',6,'2015-08-05 11:56:00','2015-08-05 11:56:00',68.00,100,0,0),(13,'澳大利亚巴罗莎干红','750ml/瓶',7,'2015-08-05 11:58:24','2015-08-05 11:58:24',278.00,100,0,0),(14,'规格','750ml/瓶',8,'2015-08-05 12:02:18','2015-08-05 12:02:18',155.00,100,0,0),(15,'规格','750ml/瓶',9,'2015-08-05 12:09:31','2015-08-05 12:09:31',65.00,100,0,0),(16,'规格','150G/袋 真空包装',11,'2015-08-05 12:22:39','2015-08-09 10:45:44',60.00,100,0,0),(17,'规格','300G/袋 真空包装',11,'2015-08-05 12:22:39','2015-08-09 10:45:44',120.00,100,0,0),(18,'规格','500G/袋 真空包装',11,'2015-08-06 02:39:36','2015-08-09 10:45:44',200.00,100,0,0),(19,'规格','150G/袋 真空包装',12,'2015-08-06 02:49:08','2015-08-06 02:49:08',51.00,100,0,0),(20,'规格','300G/袋 真空包装',12,'2015-08-06 02:49:08','2015-08-06 02:49:08',102.00,100,0,0),(21,'规格','500G/袋 真空包装',12,'2015-08-06 02:49:08','2015-08-06 02:49:08',170.00,100,0,0),(22,'规格','100克',13,'2015-08-06 03:00:58','2015-08-06 03:00:58',6.00,1000,0,0),(23,'规格','100克',14,'2015-08-06 03:06:19','2015-08-06 03:06:19',20.00,100,0,0),(24,'规格','100克',15,'2015-08-06 03:12:11','2015-08-06 03:12:11',6.00,100,0,0),(25,'规格','100克 黑',16,'2015-08-06 03:19:26','2015-08-06 03:19:26',38.00,100,0,0),(26,'规格','100克 紫',16,'2015-08-06 03:19:26','2015-08-06 03:19:26',26.00,100,0,0),(27,'规格','100克 黄',16,'2015-08-06 03:19:26','2015-08-06 03:19:26',17.00,100,0,0),(28,'规格','100克 30头',17,'2015-08-06 03:26:29','2015-08-06 03:26:29',45.00,100,0,0),(29,'规格','100克 40头',17,'2015-08-06 03:26:29','2015-08-06 03:26:29',37.00,100,0,0),(30,'规格','100克 60头',17,'2015-08-06 03:26:29','2015-08-06 03:26:29',28.00,100,0,0),(31,'规格','100克',18,'2015-08-06 03:31:09','2015-08-06 03:31:09',58.00,100,0,0),(32,'规格','100克',19,'2015-08-06 03:41:20','2015-08-06 03:41:20',150.00,100,0,0);
/*!40000 ALTER TABLE `specifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `encrypted_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reset_password_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_sent_at` datetime DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  `sign_in_count` int(11) NOT NULL DEFAULT '0',
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `current_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `tel` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `wechat_openid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_notification` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_users_on_tel` (`tel`),
  UNIQUE KEY `index_users_on_reset_password_token` (`reset_password_token`) USING BTREE,
  KEY `index_users_on_group_id` (`group_id`) USING BTREE,
  KEY `index_users_on_role` (`role`) USING BTREE,
  CONSTRAINT `fk_rails_482d5e28fd` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'rex.houy@gmail.com','$2a$10$hdZh10u6T59CRMYbiXJzluWi/nEu6llXNUQqAPwjnYcQRpQAIQ0G2',NULL,NULL,NULL,63,'2015-08-27 00:56:06','2015-08-25 02:38:19','106.37.236.228','116.52.102.127','2015-05-28 06:58:49','2015-08-27 00:56:06',1,1,0,'13914798831','o4_vLvvwTOpsgMCpHb9DXX6MswkU',1),(2,'rex.houy@live.com','$2a$10$FwTi0gmiLhwvt0Uym0Wpie.8ZpfpxxEVN7TAP.MtPPjUJNZtzzR0K',NULL,NULL,NULL,35,'2015-08-25 02:37:58','2015-08-21 05:35:37','116.52.102.127','112.112.67.115','2015-06-02 04:11:29','2015-08-25 02:37:58',2,1,0,'12345678901',NULL,NULL),(3,'807554255@qq.com','$2a$10$AbCscT6MUfl5HNQ.hOFsUOoEKO4OOtOFxEhDPA8ul.M9qSrTTx2Fi',NULL,NULL,NULL,1,'2015-06-05 08:22:18','2015-06-05 08:22:18','140.206.126.114','140.206.126.114','2015-06-05 08:22:18','2015-06-05 08:22:18',0,NULL,0,'34567890123',NULL,NULL),(4,'340060044@qq.com','$2a$10$gt9B.LS9haFJ5PmwPU3XMOrCRk9QIBZm5hpfClnj3rP2P41NPTHHe',NULL,NULL,'2015-07-02 06:16:15',6,'2015-07-06 08:45:47','2015-07-04 03:09:18','112.112.52.12','183.224.92.152','2015-06-10 15:51:04','2015-07-06 08:45:47',0,NULL,0,'45678901234',NULL,NULL),(5,'','$2a$10$vnc.DOXhGDMlk1HenLjgpO7ohaMQubOs/c5zwFmyzyppgjvionOFW',NULL,NULL,NULL,27,'2015-08-26 15:53:51','2015-08-26 01:40:29','112.112.65.220','117.136.85.72','2015-07-21 02:30:30','2015-08-26 15:53:51',0,NULL,0,'13759581670',NULL,NULL),(6,'','$2a$10$yg0uFPdOmzppfYrz8j/AsuOXvGqVcvxHYhxgX/ZfqypPOAWyjoqV2',NULL,NULL,'2015-08-14 15:04:10',29,'2015-08-26 14:04:20','2015-08-26 13:55:14','111.132.202.69','111.132.202.69','2015-07-24 09:47:32','2015-08-26 14:04:20',1,1,0,'13911085709','o4_vLvrgI_TDU0x0G0ZoL-Gp1LQg',1),(7,'','$2a$10$0ZzyIdbrz.8QxWuQmneYCeKmXNMfnL85w0LL/PpL0UYCoo5KtkktS',NULL,NULL,'2015-08-25 12:52:40',13,'2015-08-25 12:52:41','2015-08-25 12:52:41','113.160.178.76','113.160.178.76','2015-08-10 08:40:32','2015-08-25 12:52:41',1,1,0,'13808792595','o4_vLvs0-vlTeqHWouozW0RXB8hU',1),(8,'','$2a$10$r4i6JbCbZ1PXnhfROlyXQOj3xNXiaDnmmL0XaivOVJ.utFCCrBkC2',NULL,NULL,NULL,1,'2015-08-21 03:34:16','2015-08-21 03:34:16','123.116.55.120','123.116.55.120','2015-08-21 03:34:16','2015-08-21 03:34:16',0,NULL,0,'13910106520',NULL,NULL),(9,'','$2a$10$CKG3GSUjipEqCHdUmE2jZeBw5.6ToTo1jtaBsph9JyGc4cTDwlQT6',NULL,NULL,NULL,1,'2015-08-25 12:37:59','2015-08-25 12:37:59','123.113.66.69','123.113.66.69','2015-08-25 12:37:59','2015-08-25 12:37:59',0,NULL,0,'13811393962',NULL,NULL),(10,'','$2a$10$aO6E7Uvw9VxnqyPyT3lwk.j2VDmnIhCHxtffyyrW7QZMQzQrOp77S',NULL,NULL,NULL,1,'2015-08-25 13:51:47','2015-08-25 13:51:47','222.129.109.106','222.129.109.106','2015-08-25 13:51:47','2015-08-25 13:51:47',0,NULL,0,'13911667229',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-08-27 13:11:38
